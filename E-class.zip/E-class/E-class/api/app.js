const express = require('express');
const cors = require('cors');
require('dotenv').config();
const supabase = require('./supabaseClient');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// GET / - boas vindas
app.get('/', (req, res) => {
    res.status(200).json({
        mensagem: 'Bem vindo à API GamerClass',
        status: 'sucesso',
        rotas: [
            '/api/jogos',
            '/api/times',
            '/api/competidores',
            '/api/confrontos',
        ],
    });
});

// ============ JOGOS ============
app.get('/api/jogos', async (req, res) => {
    const { data, error } = await supabase.from('games').select('*');
    if (error) return res.status(500).json({ erro: error.message });
    res.status(200).json(data);
});

app.get('/api/jogos/:id', async (req, res) => {
    const { data, error } = await supabase
        .from('games')
        .select('*')
        .eq('id', req.params.id)
        .single();

    if (error) return res.status(404).json({ erro: 'Jogo não encontrado' });
    res.status(200).json(data);
});

// ============ TIMES ============
app.get('/api/times', async (req, res) => {
    const { data, error } = await supabase.from('teams').select('*');
    if (error) return res.status(500).json({ erro: error.message });
    res.status(200).json(data);
});

app.get('/api/times/:id', async (req, res) => {
    const { data, error } = await supabase
        .from('teams')
        .select('*')
        .eq('id', req.params.id)
        .single();

    if (error) return res.status(404).json({ erro: 'Time não encontrado' });
    res.status(200).json(data);
});

// ============ COMPETIDORES ============
app.get('/api/competidores', async (req, res) => {
    const { data, error } = await supabase.from('competidores').select('*');
    if (error) return res.status(500).json({ erro: error.message });
    res.status(200).json(data);
});

app.get('/api/competidores/:id', async (req, res) => {
    const { data, error } = await supabase
        .from('competidores')
        .select('*')
        .eq('id', req.params.id)
        .single();

    if (error) return res.status(404).json({ erro: 'Competidor não encontrado' });
    res.status(200).json(data);
});

// ============ CONFRONTOS (com JOIN nas tabelas relacionadas) ============
app.get('/api/confrontos', async (req, res) => {
    const { data, error } = await supabase
        .from('matches')
        .select(`
            *,
            game:games (id, name, genre),
            time1:teams!team1_id (id, name, color),
            time2:teams!team2_id (id, name, color)
        `);

    if (error) return res.status(500).json({ erro: error.message });
    res.status(200).json(data);
});

app.get('/api/confrontos/:id', async (req, res) => {
    const { data, error } = await supabase
        .from('matches')
        .select(`
            *,
            game:games (id, name, genre),
            time1:teams!team1_id (id, name, color),
            time2:teams!team2_id (id, name, color)
        `)
        .eq('id', req.params.id)
        .single();

    if (error) return res.status(404).json({ erro: 'Confronto não encontrado' });
    res.status(200).json(data);
});

// Rota não encontrada
app.use((req, res) => {
    res.status(404).json({
        erro: 'Rota não encontrada',
        mensagem: 'Apenas requisições GET são suportadas nesta API',
    });
});

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
    console.log(`Acesse: http://localhost:${PORT}`);
});